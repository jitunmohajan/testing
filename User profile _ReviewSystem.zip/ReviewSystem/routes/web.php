<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/','HomeController@login');
Route::get('organizationregister','HomeController@organizationregister');
Route::post('OrganizationDataStore','HomeController@OrganizationDataStore');
Route::post('postlogin','HomeController@postlogin');
Route::get('organizationprofile','HomeController@organizationprofile');
Route::get('edit/{id}','HomeController@edit');
Route::post('update/{id}','HomeController@update');


Route::get('register','HomeController@register');
Route::post('store','HomeController@store');
Route::get('useredit/{id}','HomeController@useredit');
Route::post('userupdate/{id}','HomeController@userupdate');

Route::get('home','HomeController@home');


Route::get('layout','HomeController@layout');