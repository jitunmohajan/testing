<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use App\UserData;
use App\Organization;
use Image;

class HomeController extends Controller
{
    public function organizationregister(){
    	return view('frontend.OrganizationRegister');
    }
    public function OrganizationDataStore(Request $req){
    	$obj=new Organization();
        $obj->name=$req->name;
    	$obj->email=$req->email;
    	$obj->address=$req->address;
        $obj->description=$req->description;
    	$obj->category=$req->category;
    	$obj->password=md5($req->password);
    	//_____________________
    	$originalImage= $req->file('filename');
        $thumbnailImage = Image::make($originalImage);
        $thumbnailPath = public_path().'/thumbnail/';
        $originalPath = public_path().'/images/';
        $thumbnailImage->save($originalPath.time().$originalImage->getClientOriginalName());
        $thumbnailImage->resize(596,619);
        $thumbnailImage->save($thumbnailPath.time().$originalImage->getClientOriginalName()); 
	    $obj->filename=time().$originalImage->getClientOriginalName();
       
    	if($obj->save()){
    		return view('frontend.login');
    	}
    	
    	

    }
    public function login(){
    	return view('frontend.login');
    }
    public function postlogin(Request $req){
        $email=$req->email;
        $password=md5($req->password);
        $obj=Organization::where('email','=',$email)
                 ->where('password','=',$password)
                 ->first();
        $obj_2=UserData::where('email','=',$email)
                 ->where('password','=',$password)
                 ->first();         
        if($obj){
            Session::put('id',$obj->id);//this pass the variable
            $sample = Organization::find($obj->id);       
            return view('frontend.OrganizationProfile',['data'=>$sample]);

        }
        else if($obj_2){
            Session::put('id',$obj_2->id);//this pass the variable
            $sample = UserData::find($obj_2->id);       
            return view('frontend.profile',['data'=>$sample]);
        		
        }
        
        else {
            return view('frontend.login');
        }
    }


    public function organizationprofile(){
    	return view('frontend.OrganizationProfile');
    }
    public function edit($id){
    	$sample = Organization::find($id);       
        return view('frontend.edit',['data'=>$sample]);
    }
    public function update(Request $req,$id){
       
        $obj = Organization::find($id);       
        $obj->description=$req->description;
        $obj->address=$req->address;

        $obj->email=$req->email;

        //_____________________
        if($req->filename!="")
        {
            $originalImage= $req->file('filename');
        $thumbnailImage = Image::make($originalImage);
        $thumbnailPath = public_path().'/thumbnail/';
        $originalPath = public_path().'/images/';
        $thumbnailImage->save($originalPath.time().$originalImage->getClientOriginalName());
        $thumbnailImage->resize(596,619);
        $thumbnailImage->save($thumbnailPath.time().$originalImage->getClientOriginalName()); 
        $obj->filename=time().$originalImage->getClientOriginalName();
       
        }
        if($obj->save()){
            $sample = Organization::find($obj->id);       
            return view('frontend.OrganizationProfile',['data'=>$sample]);
        }
    }



    public function register(){
        return view('frontend.register');
    }


    public function store(Request $req){
        $obj=new UserData();
        $obj->name=$req->name;
        $obj->email=$req->email;
        $obj->password=md5($req->password);
        //_____________________
        $originalImage= $req->file('filename');
        $thumbnailImage = Image::make($originalImage);
        $thumbnailPath = public_path().'/thumbnail/';
        $originalPath = public_path().'/images/';
        $thumbnailImage->save($originalPath.time().$originalImage->getClientOriginalName());
        $thumbnailImage->resize(596,619);
        $thumbnailImage->save($thumbnailPath.time().$originalImage->getClientOriginalName()); 
        $obj->filename=time().$originalImage->getClientOriginalName();
       
        if($obj->save()){
            return view('frontend.login');
        }
        
        

    }

    public function useredit($id){
        $sample = UserData::find($id);       
        return view('frontend.useredit',['data'=>$sample]);
    }


     public function userupdate(Request $req,$id){
       
        $obj = UserData::find($id);      
        $obj->email=$req->email;

        //_____________________
        if($req->filename!="")
        {
        $originalImage= $req->file('filename');
        $thumbnailImage = Image::make($originalImage);
        $thumbnailPath = public_path().'/thumbnail/';
        $originalPath = public_path().'/images/';
        $thumbnailImage->save($originalPath.time().$originalImage->getClientOriginalName());
        $thumbnailImage->resize(596,619);
        $thumbnailImage->save($thumbnailPath.time().$originalImage->getClientOriginalName()); 
        $obj->filename=time().$originalImage->getClientOriginalName();
       
        }
        if($obj->save()){
            $sample = UserData::find($obj->id);       
            return view('frontend.profile',['data'=>$sample]);
        }
    }

    public function home(){
        return view('backend.home');
    }

    public function layout(){
        return view('frontend.layouts.layout');
    }
}
