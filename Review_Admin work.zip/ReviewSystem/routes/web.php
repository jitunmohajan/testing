<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/','HomeController@login');
Route::get('organizationregister','HomeController@organizationregister');
Route::post('OrganizationDataStore','HomeController@OrganizationDataStore');
Route::post('postlogin','HomeController@postlogin');
Route::get('organizationprofile','HomeController@organizationprofile');
Route::get('edit/{id}','HomeController@edit');
Route::post('update/{id}','HomeController@update');
Route::get('approvallist','HomeController@approvallist');


Route::get('acceptandreject/{id}','HomeController@acceptandreject');
Route::get('accept/{id}','HomeController@accept');
Route::get('reject/{id}','HomeController@reject');