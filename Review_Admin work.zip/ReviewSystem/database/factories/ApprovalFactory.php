<?php

use Faker\Generator as Faker;

$factory->define(App\Approval::class, function (Faker $faker) {
    return [
        'name' => $faker->name,
        'email' => $faker->email,
        'address' => $faker->address,
        'description' => 'hsajhdajhjdhaskjhdkashjkashfjahsfjashfkhfsjk',
        'category' => 'Hospital',
        'filename' => $faker->imageUrl($width = 640, $height = 480),                        
        'password' => md5('123456'), // secret
        
    ];
});
